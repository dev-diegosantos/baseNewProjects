export default {
 "pt-BR": {
  itensMenu: {},
  labelsInputs: {
   logIn: "E-mail",
   password: "Senha",
  },
  buttons: {},
  textPage: {},
 },
};
