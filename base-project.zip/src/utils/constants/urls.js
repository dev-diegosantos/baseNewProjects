const urls = {
  ROUTES: {
    LOGIN: `/`
  },
  LINKS: {
    LOGIN: `/`
  }
};

export default urls;
