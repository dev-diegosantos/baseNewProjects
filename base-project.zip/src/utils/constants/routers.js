export const APP = "/";
export const TIMELINE = "/timeline";
export const MY_PROFILE = "/meu-perfil";

export const PRIVATE_ROUTERS = [TIMELINE, MY_PROFILE];
